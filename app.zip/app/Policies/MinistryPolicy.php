<?php

namespace App\Policies;

use App\Models\User;

class MinistryPolicy
{
    /**
     * Create a new policy instance.
     */
    public function __construct()
    {
        //
    }
}
